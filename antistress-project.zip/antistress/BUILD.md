# Getting an APK

The project has no Gradle wrapper jar committed (a binary I could not generate
offline), so use one of these three routes.

## 1. Android Studio, about five minutes

1. Open the `antistress` folder. Android Studio adds the wrapper on first sync.
2. Wait for Gradle sync to finish.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Click "locate" in the toast. The file is at
   `app/build/outputs/apk/debug/app-debug.apk`.
5. Copy it to your phone and open it. Allow install from unknown sources when
   prompted.

## 2. GitHub Actions, no local tooling at all

1. Push this folder to a new GitHub repository.
2. `.github/workflows/build-apk.yml` runs on push to `main`, or manually from
   the Actions tab.
3. When it finishes, download the `antistress-debug-apk` artifact from the run
   summary. That zip contains the installable APK.

This is the easiest path if you do not want Android Studio on your machine.

## 3. Command line, if you already have the SDK

    cd antistress
    gradle wrapper
    ./gradlew assembleDebug

## Note on signing

`assembleDebug` signs with the auto generated debug key. That installs fine on
your own device but cannot go to the Play Store. For a store build you need a
release keystore and a `signingConfigs` block in `app/build.gradle.kts`.

## No build at all

Open `antistress-preview.html` in Chrome on the phone, then use the browser menu
to add it to the home screen. Every toy works, including sound and vibration.
The only things you lose are the offline guarantee and the app drawer icon.
