# Antistress (WebView build)

A relaxation toy app in the style of the JindoBlu original: a timber shelf of
fiddle toys, each one a self contained interaction with generated sound and
haptics. All logic lives in one HTML file loaded from assets, so there is no
network call, no CDN and no third party library anywhere in the project.

## What is in v1

| Toy | Interaction |
| :-- | :-- |
| Fidget spinner | Flick to spin, momentum with friction decay and an rpm readout |
| Bubble wrap | Drag to pop 66 bubbles, fresh sheet button |
| Newton's cradle | Pull a ball, elastic momentum transfer across five balls |
| Kaleidoscope | Draw with twelve mirrored segments and a rotating hue |
| Lava lamp | Metaball wax via CSS blur and contrast, tap to stir |
| Sand garden | Rake seven parallel grooves, smooth it over to reset |
| Answer ball | Shake animation, twelve calm replies |
| Stress ball | Press to squash, springy release |
| Light switch | Flick on and off, full screen light change |
| Zipper | Slide the pull tab, fabric opens and closes with ratchet clicks |
| Chime bars | Eight pentatonic bars, tap or slide across |
| Water ripples | Tap to send expanding rings over an animated surface |

## Structure

    app/src/main/assets/index.html                 the whole app
    app/src/main/java/au/jindo/antistress/         WebView shell
    app/src/main/res/                              layout, theme, strings
    app/build.gradle.kts, build.gradle.kts, settings.gradle.kts

## How to build

1. Open the `antistress` folder in Android Studio (Giraffe or newer).
2. Let Gradle sync. It pulls only AppCompat and Activity KTX.
3. Add a launcher icon at `res/mipmap` (or point `android:icon` at any drawable),
   then run on a device or emulator with API 24 or above.

## Design notes

Audio is synthesised at runtime with the Web Audio API: short filtered noise
bursts for pops, clicks and rake strokes, and oscillators for the chimes and
tones. Nothing is bundled, so the APK stays tiny.

Haptics use `navigator.vibrate`, which is why the manifest declares the VIBRATE
permission. Remove the permission and the app still works, just silently on
that front.

The hardware back button is routed through `window.AntistressShell.onBack()`.
The web layer closes an open toy and reports true, otherwise the activity
finishes. That keeps navigation in one place.

Every toy exposes the same contract: a build function that receives the stage
element and returns a teardown function. Adding a thirteenth toy is one call to
`toy(id, name, icon, hint, build)` and nothing else.

## Ideas for v2

Ambient background loops, a favourites row that remembers the last five toys
opened, gyroscope input for the lava lamp and sand garden, and a night palette
that dims the shelf after dark.
